//
//  Highlighter.h
//  CameraApp
//
//  Created by sdickson on 12/20/13.
//  Copyright (c) 2013 Jay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Highlighter : UIView

@end
