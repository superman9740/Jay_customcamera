//
//  main.m
//  Contxt
//
//  Created by Chad Morris on 4/12/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BDAppDelegate class]));
    }
}
