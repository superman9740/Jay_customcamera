//
//  ContxtContact.m
//  Contxt
//
//  Created by Chad Morris on 8/10/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import "ContxtContact.h"
#import "ConversationThread.h"


@implementation ContxtContact

@dynamic email;
@dynamic firstName;
@dynamic lastName;
@dynamic parentConvoThread;

@end
