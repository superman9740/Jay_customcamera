//
//  AnnotationPoint.m
//  Contxt
//
//  Created by Chad Morris on 10/30/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import "AnnotationPoint.h"
#import "Annotation.h"
#import "DrawingAnnotation.h"


@implementation AnnotationPoint

@dynamic x;
@dynamic y;
@dynamic parentAnnotation;
@dynamic parentCenterAnnotationPoint;
@dynamic parentDrawingAnnotation;

@end
