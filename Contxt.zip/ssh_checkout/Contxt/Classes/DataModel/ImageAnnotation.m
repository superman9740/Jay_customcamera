//
//  ImageAnnotation.m
//  Contxt
//
//  Created by Chad Morris on 10/20/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import "ImageAnnotation.h"
#import "AnnotationDocument.h"


@implementation ImageAnnotation

@dynamic source;
@dynamic annotationDoc;

@end
