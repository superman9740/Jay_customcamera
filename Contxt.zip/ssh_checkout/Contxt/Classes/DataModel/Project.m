//
//  Project.m
//  Contxt
//
//  Created by Chad Morris on 8/10/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import "Project.h"
#import "AnnotationDocument.h"
#import "ImageInfo.h"


@implementation Project

@dynamic dateCreated;
@dynamic dateUpdated;
@dynamic owner;
@dynamic tags;
@dynamic title;
@dynamic annotationDocs;
@dynamic thumbnail;

@end
