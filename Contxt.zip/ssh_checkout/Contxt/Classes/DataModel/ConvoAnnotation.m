//
//  ConvoAnnotation.m
//  Contxt
//
//  Created by Chad Morris on 8/10/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import "ConvoAnnotation.h"
#import "ConversationThread.h"


@implementation ConvoAnnotation

@dynamic convoThread;

@end
