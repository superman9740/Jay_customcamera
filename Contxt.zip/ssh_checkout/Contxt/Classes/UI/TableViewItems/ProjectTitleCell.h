//
//  ProjectTitleCell.h
//  Contxt
//
//  Created by Chad Morris on 5/2/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProjectTitleCell : UITableViewCell

@property (nonatomic , retain) IBOutlet UILabel * label;
@property (nonatomic , retain) IBOutlet UITextField * details;

@end
