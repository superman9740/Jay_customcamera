//
//  NSDictionary+Contains.h
//  Contxt
//
//  Created by Chad Morris on 8/28/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Contains)

- (BOOL)containsKey:(NSString *)key;

@end
