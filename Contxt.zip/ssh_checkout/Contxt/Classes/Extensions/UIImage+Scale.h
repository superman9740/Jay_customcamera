//
//  UIImage+Scale.h
//  Contxt
//
//  Created by Chad Morris on 5/6/13.
//  Copyright (c) 2013 Chad Morris. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (scale)

-(UIImage*)scaleToSize:(CGSize)size;

@end